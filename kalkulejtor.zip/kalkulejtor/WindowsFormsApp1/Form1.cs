﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Licznik : Form
    {
        int liczba;
        public Licznik()
        {
            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            int x = Convert.ToInt16(textBoxlicznik.Text);
            x = x*x;
            textBoxlicznik.Text = Convert.ToString(x);
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            string s = "";
            if(textBoxlicznik.Text[0] == '#')
            {
                s = "1";
            }
            else
            {

            }
            textBoxlicznik.Text = s;


        }

        private void button1_Click(object sender, EventArgs e)
        {
            int x = Convert.ToInt16(textBoxlicznik.Text);
            x = x + 2;
            textBoxlicznik.Text = Convert.ToString(x);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            int x = Convert.ToInt16(textBoxlicznik.Text);
            x = x + 3;
            textBoxlicznik.Text = Convert.ToString(x);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            int x = Convert.ToInt16(textBoxlicznik.Text);
            x = x + 4;
            textBoxlicznik.Text = Convert.ToString(x);
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            int x = Convert.ToInt16(textBoxlicznik.Text);
            x = x + 5;
            textBoxlicznik.Text = Convert.ToString(x);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            int x = Convert.ToInt16(textBoxlicznik.Text);
            x = x + 6;
            textBoxlicznik.Text = Convert.ToString(x);
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            int x = Convert.ToInt16(textBoxlicznik.Text);
            x = x + 7;
            textBoxlicznik.Text = Convert.ToString(x);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            int x = Convert.ToInt16(textBoxlicznik.Text);
            x = x + 8;
            textBoxlicznik.Text = Convert.ToString(x);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int x = Convert.ToInt16(textBoxlicznik.Text);
            x = x + 9;
            textBoxlicznik.Text = Convert.ToString(x);
        }

        private void button11_Click(object sender, EventArgs e)
        {
            int x = Convert.ToInt16(textBoxlicznik.Text);
            x = 0;
            textBoxlicznik.Text = Convert.ToString(x);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Random x = new Random();
            int liczba = x.Next(0, 1000);
            int ile = 0;
            string s = " ";
            while(liczba > 0){ liczba /= 10; ile++;}
            for(int i = 0; i < ile; i++)
            {
                s = s + "#";
            }
            textBoxlicznik.Text = s;







        }

        private void button2_Click(object sender, EventArgs e)
        {
            int x = Convert.ToInt16(textBoxlicznik.Text);
            x = x*x;
            textBoxlicznik.Text = Convert.ToString(x);
        }
    }
}
